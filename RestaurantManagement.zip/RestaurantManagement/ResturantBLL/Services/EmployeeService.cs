﻿using RestaurantDAL.Repost;
using RestaurantEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ResturantBLL.Services
{
    public class EmployeeService
    {
        IEmployeeRepository _employeeRepository;
        public EmployeeService(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        //Add User
        public void AddEmployee(Employee employee)
        {
            _employeeRepository.AddEmployee(employee);
        }
        //Update User
        public void UpdateEmployee(Employee employee)
        {
            _employeeRepository.UpdateEmployee(employee);
        }

        //Delete User
        public void DeleteEmployee(int employeeId)
        {
            _employeeRepository.DeleteEmployee(employeeId);
        }

        //Get UserByID
        public Employee GetEmployeeById(int employeeId)
        {
            return _employeeRepository.GetEmployeeById(employeeId);
        }

        //Get Users
        public IEnumerable<Employee> GetEmployees()
        {
            return _employeeRepository.GetEmployee();
        }


        public void Register(Employee employeeInfo)
        {
            _employeeRepository.Register(employeeInfo);
        }
        public Employee Login(Employee employeeInfo)
        {
            return _employeeRepository.Login(employeeInfo);
        }

    }
}
