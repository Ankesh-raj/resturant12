﻿using RestaurantEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace RestaurantDAL.Repost
{
    public interface IEmployeeRepository
    {

        void AddEmployee(Employee employee);

        void UpdateEmployee(Employee employee);

        void DeleteEmployee(int employeeId);

        Employee GetEmployeeById(int employeeId);

        void Register(Employee employeeInfo);
        Employee Login(Employee employee);
        IEnumerable<Employee> GetEmployee();
    }
}
