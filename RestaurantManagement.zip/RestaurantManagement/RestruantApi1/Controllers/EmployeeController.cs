﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestaurantEntity;
using ResturantBLL;
using ResturantBLL.Services;
using System.Collections.Generic;

namespace RestruantApi1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private EmployeeService _employeeService;

        public EmployeeController(EmployeeService employeeService)
        {
            _employeeService = employeeService;
        }
        [HttpGet("GetEmployees")]//
        public IEnumerable<Employee> GetEmployees()
        {
            return _employeeService.GetEmployees();
        }

        [HttpPost("AddEmployee")]
        public IActionResult AddEmployee([FromBody] Employee employee)
        {
            _employeeService.AddEmployee(employee);
            return Ok("Employee created Successfully");
        }

        [HttpDelete("DeleteEmployee")]
        public IActionResult DeleteEmployee(int employeeId)
        {
            _employeeService.DeleteEmployee(employeeId);
            return Ok("Employee deleted Successfully");
        }

        [HttpPut("UpdateEmployee")]
        public IActionResult UpdateEmployee([FromBody] Employee employee)
        {
            _employeeService.UpdateEmployee(employee);
            return Ok("Employee Updated Successfully");
        }

        [HttpGet("GetEmployeeById")]
        public Employee GetEmployeeById(int employeeId)
        {
            return _employeeService.GetEmployeeById(employeeId);
        }
        [HttpPost("Register")]
        public IActionResult Register([FromBody] Employee employeeInfo)
        {
            _employeeService.Register(employeeInfo);
            return Ok("Register successfully!!");
        }
        [HttpPost("Login")]
        public IActionResult Login([FromBody] Employee employeeInfo)
        {
            Employee employee = _employeeService.Login(employeeInfo);
            if (employee != null)
                return Ok("Login success!!");
            else
                return NotFound();
        }
    }
}
